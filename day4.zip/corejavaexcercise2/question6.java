package corejavaexcercise2;

public class question6 {

	public  static int calculateWordSum(String first,String second)
	{
		if(first.equals(second))
		{
			return first.length();		}
		else
		{
			return first.length()+second.length();
		}
	}
}
