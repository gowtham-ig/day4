package corejavaexcercise2;
import java.util.Scanner;

public class question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a statement:");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String arr[]=s.split(" ");
//		for(String t:arr)
//		{
//			System.out.println(t);
//		}
		for(int i=0;i<arr.length;i++)
		{
			char temp=Character.toUpperCase(arr[i].charAt(0));
			arr[i]=arr[i].replace(arr[i].charAt(0), temp);
		//	System.out.println(arr[i]);
		}
		String result="";
		for(int i=0;i<arr.length;i++)
		{
			result=result+arr[i];
			result=result+" ";
		}
		System.out.println(result);
			
			
		

	}

}
