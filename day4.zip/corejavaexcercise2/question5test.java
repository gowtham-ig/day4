package corejavaexcercise2;

public class question5test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="hi hello i am gowtham";
		question5 q=new question5();
		System.out.println( q.getLastLetter(s));

	}

}
