package corejavaexcercise2;

public class question2 {
//	2.Write tester class, Program2 to read an integer array and find the index of larger 
//	number of the two adjacent numbers with largest difference. Print the index.
//	Write a static method findMaxDistance which accepts an integer array and the number of elements in the array. 
//	The return type (Integer) should return index.
//
//	Refer sample output for formatting specifications.
//	Sample Input :
//
//	4
//	8
//	6
//	1
//	9
//	4
//	Sample Output :
//	4
	public static void main(String args[])
	{
		int [] arr= {4,8,6,1,9,4};
		int max=0;
		int index=0;
		int diff=0;
		for(int i=0;i<arr.length-1;i++)
		{
			 diff=Math.abs(arr[i]-arr[i+1]);
			if(diff>max)
			{
				max=diff;
				int value=Math.max(arr[i], arr[i+1]);
				if(arr[i]==value)
				{
					index=i;
				}
				else
				{
					index=i+1;
				}
			}
			
		}
		System.out.println(index);
	}
	

}
