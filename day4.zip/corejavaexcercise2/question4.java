package corejavaexcercise2;

public class question4 {
	public static String reshape(String s,char c)
	{
//		StringBuilder s1=new StringBuilder(s);
//		s1=s1.reverse();
//		String s3=s1.toString();
//		StringBuilder s2=new StringBuilder();
//		for(int i=0;i<s1.length();i++)
//		{
//			s2=s2+Character.toString(s3.charAt(i));
//		}
//	}
		StringBuilder s1=new StringBuilder();
		for(int i=s.length()-1;i>0;i--)
		{
			s1=s1.append(s.charAt(i));
			s1.append(c);
		}
		s1.append(s.charAt(0));
		return s1.toString();

}}
