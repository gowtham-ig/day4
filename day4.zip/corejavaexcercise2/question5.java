package corejavaexcercise2;

public class question5 {
	public String getLastLetter(String s)
	{
		String arr[]=s.split(" ");
		StringBuilder s1=new StringBuilder();
		for(int i=0;i<arr.length;i++)
		{
			s1.append(Character.toUpperCase(arr[i].charAt(arr[i].length()-1)));
		}
		return s1.toString();
	}

}
