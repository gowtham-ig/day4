package corejavaexcercise2;

public class question6test {
	public static void main(String args[])
	{
		String s="i am gowtham ";
		String arr[]=s.split(" ");
		question6 q=new question6();
		System.out.println(q.calculateWordSum(arr[0], arr[arr.length-1]));
		
		
	}

}
