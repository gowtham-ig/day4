package corejavaexcercise2;

public class question7 {
	public static String convertFormat(String s)
	{
		
//		Sample Input:
//			555-666-1234
////			 
//			Sample Output:
//			55-56-661-234
		String arr[]=s.split("-");
				
		StringBuilder s1=new StringBuilder();
		for(int i=0;i<arr.length;i++)
		{
			s1=s1.append(arr[i]);
			
		}
		String ans=s1.substring(0,2)+"-"+s1.substring(2,4)+"-"+s1.substring(4,7)+"-"+s1.substring(7);
		return ans;
	}
	

}
