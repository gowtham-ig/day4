package corejavaexcercise2;

public class question3 {
	public static void main(String args[])
	{
		String s="ALD3245A";
//		boolean something=true;
//		if(s.length()==8) {
//			for(int i=0;i<3;i++) {
//				if(Character.isLetter(s.charAt(i))&&Character.isUpperCase(s.charAt(i))) {
//					continue;}
//				else{
//					something=false;	
//					System.out.println("Invalid");
//					break;}}
//			if(something){
//				for(int i=3;i<8;i++){
//					if(Character.isDigit(s.charAt(i))){
//						something=false;}
//					else{
//						System.out.println("Invalid");
//						something=true;
//						break;}}
//				if(!something){
//					System.out.println("valid");}}}
//		else{
//			System.out.println("Invalid");}}}
		//String pattern=""
		if(s.matches("[A-Z]{3}[0-9]{4}[A-Z]{1}"))
		{
			System.out.println("Valid");
		}
		else
		{
			System.out.println("Invalid");
		}}}
