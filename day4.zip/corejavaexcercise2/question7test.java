package corejavaexcercise2;

public class question7test {
	public static void main(String args[])
	{
		String s="555-666-1234";
		System.out.println(question7.convertFormat(s));
	}

}
