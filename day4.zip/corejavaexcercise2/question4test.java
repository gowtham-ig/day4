package corejavaexcercise2;

public class question4test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="rabbit";
		char c='-';
		//question4 q=new question4();
		System.out.println( question4.reshape(s, c));
		

	}

}
