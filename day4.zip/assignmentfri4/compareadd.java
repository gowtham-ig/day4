package assignmentfri4;

public class compareadd {

}
