package assignmentfri4;
import java.util.*;

public class test {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		HashSet<student> set=new HashSet<>();
		HashMap<String,Address> h1=new HashMap<>();
		boolean something =true;
		while(something)
		{
		System.out.println("enter the age:");
		int age=sc.nextInt();
		System.out.println("enter the First Name:");
		String Fname=sc.next();
		System.out.println("enter the Last Name:");
		String Lname=sc.next();
		System.out.println("enter your house number:");
		String hno=sc.next();
		System.out.println("enter your street:");
		String street=sc.next();
		System.out.println("enter your district,state,pincode:");
		String eadd=sc.next();
		Address a1=new Address();
		a1.setHno(hno);
		a1.setStreet(street);
		a1.setEadd(eadd);
		student s=new student();
		s.setAge(age);
		s.setFname(Fname);
		s.setLname(Lname);
		s.setAddress(a1);
		set.add(s);
		System.out.println("do u want to continue to add");
		String responce=sc.next();
		if(responce.equals("N"))
		{
			something=false;
		}
		
//		validatestrings va=new validatestrings();
//		System.out.println(va.compareFullNames(Fname+" "+Lname, Fname))
		

	}
		Iterator<student> iterator = set.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
	}

}
