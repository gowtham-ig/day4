package assignmentfri4;

public class Address {
	private String hno;
	private String street;
	private String eadd;
	public String getHno() {
		return hno;
	}
	public void setHno(String hno) {
		this.hno = hno;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getEadd() {
		return eadd;
	}
	public void setEadd(String eadd) {
		this.eadd = eadd;
	}
//	public Address(String hno, String street, String eadd) {
//		super();
//		this.hno = hno;
//		this.street = street;
//		this.eadd = eadd;
//	}
	@Override
	public String toString() {
		return "Address [hno=" + hno + ", street=" + street + ", eadd=" + eadd + "]";
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 1;
	}
	@Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Address address = (Address) obj;
        return hno.equals(address.hno) &&
               street.equals(address.street) &&
               eadd.equals(address.eadd);
    }
	
	

}
