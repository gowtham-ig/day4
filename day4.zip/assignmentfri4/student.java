package assignmentfri4;

import java.util.Objects;

public class student  {
	
	
	
	private Integer age;
	private String Fname;
	private String Lname;
	private Address a1;
	
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public Address getAddress()
	{
		return a1;
	}
	public void setAddress(Address a1)
	{
		this.a1=a1;
	}
//	public String name(String Fname,String Lname)
//	{
//		return Fname+" "+Lname;
//	}
//	
	@Override
	public String toString() {
		return "student [age=" + age + ", Fname=" + Fname + ", Lname=" + Lname + ", a1=" + a1 + "]";
	}
	
	 public int hashCode() {
	        return Objects.hash(Fname, Lname);
	    }
	 @Override
	    public boolean equals(Object obj) {
	        if (this == obj) return true;
	        if (obj == null || getClass() != obj.getClass()) return false;
	        student s = (student) obj;
	        return Objects.equals(Fname, s.Fname) &&
	               Objects.equals(Lname, s.Lname) &&
	               Objects.equals(a1, s.a1);
	    }
	
	
//	student(Integer age,String Fname,String Lname,String add)
//	{
//		super(add);
//		this.age=age;
//		this.Fname=Fname;
//		this.Lname=Lname;
//	}
	

}
