package assigncitystate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class read {
    private HashMap<String, String> h1 = new HashMap<>();

    public HashMap<String, String> reading() throws IOException {
        BufferedReader b = new BufferedReader(new FileReader("C:/Users/GowthamThotakuri/OneDrive - Insight Global, LLC/Desktop/testfile.txt"));
        String line;
       // System.out.println("hello");
        String[] arr;

        while ((line = b.readLine()) != null) {
           // System.out.println(line);
            arr = line.split(" ");
            if (arr.length >= 2) {
               // System.out.println(arr[0] + " " + arr[1]);
                h1.put(arr[0], arr[1]);
            }
        }

        b.close();
        return h1;
    }

    
}
