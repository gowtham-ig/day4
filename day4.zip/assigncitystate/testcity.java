package assigncitystate;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class testcity {

	public static void main(String[] args) throws IOException {
		boolean something=true;
		Scanner sc=new Scanner(System.in);
		
		HashMap<String,String> h1=new HashMap<>();
//	System.out.println("1");
		read r=new read();
		h1=r.reading();
	//	System.out.println("2");
		citystate cs=new citystate();
		while(something)
		{
			System.out.println("click on the menu...");
			System.out.println("1.get all cities");
			System.out.println("2.get all states");
			System.out.println("3.get city for a state");
			System.out.println("4.get state for a city");
			System.out.println("5.add new city state pair");
			System.out.println("6.delete all cities of a given state");
			System.out.println("7.exit");
			int responce=sc.nextInt();
			switch(responce) {
			case 1:cs.getAllCities(h1);
			break;
			case 2:cs.getAllStates(h1);
			break;
			case 3:
				System.out.println("enter a state:");
				String state=sc.next();
				cs.getCitiesforaState(h1,state);
				break;
			case 4:
				System.out.println("enter the city: ");
				String city=sc.next();
				System.out.println( cs.getstateforCity(h1, city));
				break;
			case 5:
				System.out.println("enter the city: ");
				 city=sc.next();
				System.out.println("enter a state:");
				 state=sc.next();
				cs.addcity(h1, city, state);
				break;
			case 6:
				System.out.println("enter the state to delete all its cities:");
				 state=sc.next();
				cs.deleteAllcitiesofaState(h1, state);
				break;
			case 7:
				something=false;
				break;
				
				
			}
			
		}
sc.close();
	}

}
