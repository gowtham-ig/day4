package assigncitystate;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

public class citystate {
	
	public String getstateforCity(HashMap<String,String> h1,String city)
	{
		return h1.get(city);
		
	}
	public void addcity(HashMap<String,String> h1,String city,String state)
	{
		h1.put(city, state);
	}
	public void getAllCities(HashMap<String,String> h1)
	{
		for(Map.Entry<String,String> entry:h1.entrySet())
		{
			System.out.println(entry.getKey());
			
		}
	}
	public void getAllStates(HashMap<String,String> h1)
	{
		HashSet<String> hs=new HashSet<>();
		for(Map.Entry<String,String> entry:h1.entrySet())
		{
			hs.add(entry.getValue());
		}
		for(String s:hs)
		{
			System.out.println(s);
		}
	}
	public void deleteAllcitiesofaState(HashMap<String,String> h1,String state)
	{
		Iterator<Map.Entry<String,String >> entry=h1.entrySet().iterator();
		while(entry.hasNext())
		{
			Map.Entry<String, String> e=entry.next();
			if (e.getValue().equals(state)) {
                entry.remove();
            }
			
		
		}
	}
	public void getCitiesforaState(HashMap<String,String> h1,String state)
	{
		Iterator<Map.Entry<String, String>> iterator=h1.entrySet().iterator();	
		while(iterator.hasNext())
		{
			Map.Entry<String,String> entry=iterator.next();
			if(entry.getValue().equals(state))
			{
				System.out.println(entry.getKey());
			}
			
		
		}
	}
	

}
