package Employeespack;

import java.util.Comparator;

public class EmployeeComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		Employee e1=(Employee)o1;
		Employee e2=(Employee)o2;
		if(e1.getFirstname().compareTo(e2.getFirstname())>0)
		{
			return 1;
		}
		else
		{
			return -1;
		}
		//return 0;
	}
	

}
