package Employeespack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Employytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee> lis1=new ArrayList<>();
		Employee e1=new Employee();
		e1.setEmpid(101);
		e1.setFirstname("gowtham");
		e1.setLastname("thotakuri");
		Employee e2=new Employee();
		e2.setEmpid(201);
		e2.setFirstname("ramesh");
		e2.setLastname("fivestar");
		Employee e3=new Employee();
		e3.setEmpid(100);
		e3.setFirstname("suresh");
		e3.setLastname("perk");
		Employee e4=new Employee();
		e4.setEmpid(1134);
		e4.setFirstname("mahesh");
		e4.setLastname("superstar");
		lis1.add(e4);
		lis1.add(e3);
		lis1.add(e2);
		lis1.add(e1);
		lis1.forEach(x->System.out.println(x));
		Collections.sort((List<Employee> )lis1,new EmployeeEmpiComparator());
		System.out.println("sorted based on empid:");
		lis1.forEach(x->System.out.println(x));
		Collections.sort((List<Employee> )lis1,new EmployeeComparator());
        System.out.println("sorted based on FirstName:");

	}

}
