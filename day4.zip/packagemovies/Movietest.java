package packagemovies;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Movietest {
	public static void main(String args[])
	{
		List<Movies> lis1=new ArrayList<Movies>();
		Movies m1=new Movies("gowtham","telugu","24-10-2003","insight","global",130);
		Movies m2=new Movies("SSMB29","english","12-01-2028","rajamouli","k v Narayana",237);
		Movies m3=new Movies("Devara2","hindi","24-10-2029","koratala","shiva",170);
		Movies m4=new Movies("pushpa","malayalam","12-01-2030","sukumar","ravi",300);
		lis1.add(m1);
		lis1.add(m2);
		lis1.add(m3);
		lis1.add(m4);
		//Movies m=new Movies();
		Collections.sort(lis1);
		lis1.forEach(x->System.out.println(x));
		System.out.println("********************************************");
		Collections.sort((List<Movies>) lis1,new sortByDuration());
		lis1.forEach(x->System.out.println(x));

		
		
	}

}
