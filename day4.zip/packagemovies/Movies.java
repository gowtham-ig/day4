package packagemovies;

public class Movies implements Comparable<Movies>{
	String name;
	String language;
	String releasedate;
	String director;
	String producer;
	Integer duration;
	public Movies(String name, String language, String releasedate, String director, String producer, Integer duration) {
		super();
		this.name = name;
		this.language = language;
		this.releasedate = releasedate;
		this.director = director;
		this.producer = producer;
		this.duration = duration;
	}
	
	public int compareTo(Movies that)
	{
		if(this.language.compareTo(that.language)>1)
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}

	@Override
	public String toString() {
		return "Movies [name=" + name + ", language=" + language + ", releasedate=" + releasedate + ", director="
				+ director + ", producer=" + producer + ", duration=" + duration + "]";
	}
	
	
	
	

}
