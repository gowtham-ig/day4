package packagemovies;

import java.util.Comparator;

public class sortByDuration implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		Movies m1=(Movies)o1;
		Movies m2=(Movies)o2;
		if(m1.duration>m2.duration)
		{
			return 1;
		}
		else
			{return -1;
	}
	
	
	}
}
 